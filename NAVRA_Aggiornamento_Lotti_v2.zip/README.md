# NAVRA · Aggiornamento Lotti acquistati v2.0

Questo è un aggiornamento per la versione già esistente nel repository `ranieristeno/navra-offline`, non un'app separata. Il database e i record esistenti non vanno cancellati.

## Funzioni

- Nuova sezione **Lotti**: fornitore, data, numero orologi, prezzo complessivo, spedizione, spese comuni, pagante, quote soci, note.
- Ad ogni nuovo lotto NAVRA crea una scheda Orologio per ciascuna unità (`Da catalogare`), per conservare foto, modello, vendita e storico per singolo esemplare.
- Ripartizione **equa** esatta ai centesimi, senza somme arrotondate erroneamente.
- Ripartizione **manuale** per ogni orologio, sia per il prezzo di acquisto sia per le spese accessorie. Viene verificato che le somme corrispondano al totale lotto.
- Correzioni ai prezzi di un lotto aggiornano i costi degli orologi collegati, incluso il magazzino, il margine e il registro Costi quando è indicato chi ha pagato.
- Salvataggio offline in IndexedDB e sincronizzazione con Firebase tramite l'adapter già esistente. La sincronizzazione va configurata nell'app; non viene attivata automaticamente soltanto dall'aggiornamento.
- I record `lot` sono inclusi nei backup JSON grazie alla nuova voce di schema. La reportistica Excel preesistente non comprende ancora un foglio dedicato ai lotti.

## Installazione nel repository (senza cancellare gli altri file)

1. Caricare `navra-lotti.js` nella radice del repository, accanto a `app.js` e `navra-upgrade.js`.
2. **Nel file `index.html`**, dopo la riga `<script src="./navra-upgrade.js" defer></script>` e PRIMA della riga `</body>`, inserire:

   `<script src="./navra-lotti.js" defer></script>`

3. Sostituire il file `sw.js` con quello allegato, per includere il modulo nei file necessari all'uso offline. **Non modificare** `manifest.webmanifest` né i file immagini.
4. Dopo aver pubblicato il sito, aprire NAVRA con connessione Internet, attendere la prima sincronizzazione e ricaricare la pagina; quindi provare l'apertura senza rete.

**Prima di aggiornare:** aprire NAVRA → Impostazioni → Scarica backup, e conservare il file JSON.

**Nota di contabilità:** i prezzi del lotto sono ripartiti sugli orologi collegati, che costituiscono la sorgente dei costi di acquisto. **Non inserire anche il totale lotto come spesa manuale nei Costi**, per evitare doppioni. La sezione Lotti non crea un secondo costo aggregato. L'inserimento in Cassa resta distinto.

**Attenzione:** il lotto crea schede nuove; nella v2.0 non è ancora disponibile associare orologi già inseriti prima della creazione del lotto. Se un orologio è già stato registrato, prima di crearne uno nuovo verifica di non duplicarlo. Per questa ragione la quantità di un lotto non è modificabile dopo la creazione, e il lotto non può essere cancellato direttamente. Si possono modificare prezzi, date, fornitore e metodo di ripartizione.

## Test consigliati

- Lotto da 3 orologi, €200 acquisto e €30 spedizione → costo totale €230, sommatoria degli orologi €230.
- Manuale: €100, €60 e €40 di acquisto; €10 di spedizione a ognuno → totale €230.
- Salvataggio di una foto e di una vendita non deve scollegare l'orologio dal lotto.
- Verificare l'app sia offline sia con due diversi account Firebase nello stesso gruppo.
